# POST Request in Expressjs 4

Download code and run

```
npm install
```
```
node server.js
```

Visit ```http://localhost:3000``` to view the app.

Watch the demo [here](https://www.youtube.com/watch?v=C3G3N4LMJeE)